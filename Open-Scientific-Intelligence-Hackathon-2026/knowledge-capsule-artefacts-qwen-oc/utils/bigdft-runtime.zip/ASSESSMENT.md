# Runtime assessment — 2026-10-19

Tested image: bigdft/runtime@sha256:6f16f65f5b33ffe83e53d3c228c21a1e8eb97d0b426f4fad0c805d0bc0540336
Platform: linux/amd64. Image creation: 2021-10-21T14:32:48.375097644Z.

The corrected CPU H2 smoke passes with EKS = -1.1367207275995557 hartree
and gradient norm 7.2e-5 (threshold 1e-4). It was executed from actual
RemoteManager 0.14.3 Function-emitted source in a fresh Python namespace, after
resolving the included source_file registry. This verifies helper packaging and
real Docker execution; a remote Dataset campaign has not been run.

The first host-UID run failed with exit 127 and a missing-MKL loader message.
Investigation found /usr/local/anaconda/lib owned by root:1000 with mode 770.
Adding --group-add 1000 fixes access without changing the image or host files.
The final function defaults library_group=1000 for this historical image.
For other images inspect their permissions and choose that argument accordingly.

The image reports BigDFT 1.9.1 in both log.yaml and pkg-config. Its JHBuild entry
was installed on 2021-10-21 and does not provide a usable source commit.
The local suite HEAD is 1c8818b8b65eab0068091cd90de168ab5afe1f40;
bigdft/.gitrepo records 66dbb1b3738f86063ffb631eea14adc651301d6c and
configure.ac uses 1.9.5 as its git-version-gen fallback. This checkout also has
pre-existing local changes, recorded by filename in provenance.json.
Thus the historical image is not in sync with the current code. Exact component
differences cannot be reconstructed from the image's available version metadata.
No current-checkout binary was built or compared numerically in this work.

The live RemoteManager MCP registry contained BigDFT entries with import errors.
This capsule supplies a separate working registry entry and self-contained function;
it does not repair those unrelated campaign functions. See RECEIVING.md for setup.

A second capsule should demonstrate a pinned build from the current code, with
component revisions, local patches, base/SDK digests and rcfiles, followed by the
same smoke and MPI validation. Existing ContainerXP recipes are starting points,
not yet validated current build procedures. No image build/publish was performed.
