# Run BigDFT from a Docker runtime

This capsule documents a CPU H2 smoke calculation in an existing runtime image.
Use the pinned digest in evidence/smoke-fixed/result.json after the recorded test completes.
The image is downloaded separately; the capsule contains no image layers.

## Requirements and first run

Use a Linux Docker host with a working Docker daemon, permission to run containers,
and Python 3.9 or later. The Python function runs on the Docker host, invokes the
container's `bigdft` executable, and needs only the Python standard library.
PyBigDFT and RemoteManager are optional on the host. For this capsule the
validated pinned image is
`bigdft/runtime@sha256:6f16f65f5b33ffe83e53d3c228c21a1e8eb97d0b426f4fad0c805d0bc0540336`. Docker bind source paths must
exist on the daemon host; a remote Docker context with a different filesystem
requires staging the directory there first.

From the capsule directory:

```bash
docker pull bigdft/runtime:latest
python3 runtime_smoke.py bigdft/runtime:latest --workdir smoke-first-run
```

For reproduction, replace the moving tag with the recorded `bigdft/runtime@sha256:...`
RepoDigest. Pull that digest first. Each run needs a new output directory, preventing
old log files from producing false success. The function records input.yaml,
stdout.txt, stderr.txt, log.yaml, image.json and result.json. It runs with the host
UID/GID plus supplementary group 1000 (needed to read this image's MKL), one OpenMP/MKL thread, unlimited stack, no container network, and a writable
bind mount at /work. The explicit command `bigdft` replaces the image's notebook
CMD. No source checkout or compiler is required for this execution path.

The molecule is neutral H2 at 0.74 angstrom, isolated, LDA (ixc=1), using built-in
pseudopotentials and a 0.5 bohr wavelet grid. Pass means exit code zero, a finite
final EKS between -2 and -0.5 hartree, and final gradient norm <= 1e-4. This is a
runtime and convergence check, not an accuracy benchmark. GPU, multi-rank MPI,
PyBigDFT import compatibility and scientific production convergence are separate
checks. The YAML input guidance follows the local bigdft-input-preparation skill;
that skill carries GPL-3.0-or-later and upstream MIT attribution.

## RemoteManager registry

The included function-registry.yaml uses a source_file relative to the registry.
It can be used as a standalone trusted registry by configuring the server's
REMOTEMANAGER_MCP_FUNCTION_REGISTRY to its absolute path before starting the server.
Alternatively merge its named entry into an existing registry and make source_file
absolute. Existing registry entries should be preserved.

The callable has all imports inside its body and no external helper functions.
The actual RemoteManager Function serializer output is retained in evidence/.
Run it on a Docker-capable execution host. RemoteManager transports Python code;
it does not automatically transport Docker images or enable Docker on an HPC node.
Pass image explicitly (preferably a digest), workdir as a fresh absolute directory
on the execution host, and timeout in seconds. Resolve/list the registry function
before creating a campaign. A return dictionary is small; input and logs remain
on the execution host and must be retrieved separately for a remote campaign.

## Source alignment

Read ASSESSMENT.md and the recorded evidence. A passing calculation establishes
only that this input works with that image. It does not establish equality with
this checkout. Compare embedded revision/build metadata against the suite commit,
each relevant subrepo commit, and local patches. The current checkout is dirty.
If source provenance is absent, report alignment as unknown even when version
strings agree. Image creation time and a `latest` tag are insufficient evidence.

## Possible second capsule: build the runtime

A separate build capsule would complement this usage capsule. Pin the suite and
ContainerXP revisions, base/SDK image digests, rcfile, dependency versions, target
architecture and build options. Record all local patches and build-generated
metadata. The existing ContainerXP hpccm/hpccm_lsim-bigdft.py plus runtime.yml describe
one historical path; Dockerfiles/Dockerfile-bigdft with target runtime-core is
another documented path. Validate the chosen recipe before treating either as a
current, reproducible build procedure.

Build in an isolated work directory, attach OCI source/revision labels plus a
component manifest, export an SBOM and compiler/library versions, run this exact
smoke test and an MPI test, and preserve the produced digest and CI logs. Compare
the new runtime with the existing digest using identical inputs. Building or
publishing a new runtime is future work, outside this capsule's execution scope.
