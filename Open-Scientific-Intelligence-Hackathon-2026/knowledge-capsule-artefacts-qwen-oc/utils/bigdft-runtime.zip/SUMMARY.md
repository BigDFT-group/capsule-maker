# Research Capsule

Employ BigDFT from a Docker runtime, reproduce a smoke test, assess source alignment, and scope a future build capsule

Origin: local-json — Curated BigDFT Docker runtime investigation

## Knowledge

### alignment (result, verified)

Historical runtime reports 1.9.1 and was created in 2021; it is not synchronized with the current 2026 checkout. Exact source commit is unavailable.

Evidence: observations
Provenance: session
Supersedes: none

### next-build (question, unresolved)

Prepare a separate capsule for pinned current-source runtime image creation, component provenance, and smoke/MPI validation.

Evidence: none
Provenance: session
Supersedes: none

### observations (evidence, verified)

Recorded real Docker smoke failure and corrected passing run, image metadata, source provenance, and RemoteManager-emitted source.

Evidence: none
Provenance: session
Supersedes: none

### usage (procedure, verified)

Run a CPU H2 smoke test using the pinned historical Docker runtime; include supplementary library group 1000.

Evidence: observations
Provenance: session
Supersedes: none

## Source references

- session: urn:bigdft:runtime:2026-10-19 — Observed Docker execution and local source inspection; agent-reviewed, no human review claimed

## Conflicts

None declared or detected.

## Environment

Python >=3.9,<4

## Receiving instructions

Inspect the manifest, knowledge, evidence, procedures, and tests before approval.
Verify integrity and environment requirements. Import/inspection never run code.
Run tests only after explicit trust using `capsule-maker verify PATH --trust-code`.
Checksums establish integrity, not authorship or scientific validity.
