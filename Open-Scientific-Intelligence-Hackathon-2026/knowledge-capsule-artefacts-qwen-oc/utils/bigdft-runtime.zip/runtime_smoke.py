# SPDX-License-Identifier: GPL-3.0-or-later
"""Self-contained host-side callable suitable for RemoteManager serialization."""
def bigdft_runtime_smoke(image, workdir='bigdft-runtime-smoke', timeout=180, library_group=1000):
    import json
    import math
    import os
    from pathlib import Path
    import re
    import subprocess
    import uuid

    root = Path(workdir).resolve()
    root.mkdir(parents=True, exist_ok=False)
    inp = '''dft:
  ixc: 1
  hgrids: 0.5
  rmult: [5.0, 8.0]
  gnrm_cv: 1.e-4
  itermax: 50
posinp:
  units: angstroem
  positions:
  - H: [0.0, 0.0, 0.0]
  - H: [0.0, 0.0, 0.74]
'''
    (root / 'input.yaml').write_text(inp)
    meta = json.loads(subprocess.check_output(['docker', 'image', 'inspect', image], text=True))[0]
    (root / 'image.json').write_text(json.dumps({k:meta.get(k) for k in ['Id','RepoDigests','Created','Architecture','Os','Config']}, indent=2))
    name = 'bigdft-smoke-' + uuid.uuid4().hex[:12]
    cmd = ['docker','run','--rm','--name',name,'--network','none',
           '--user',str(os.getuid())+':'+str(os.getgid()),
           '--group-add',str(library_group),
           '--env','OMP_NUM_THREADS=1','--env','MKL_NUM_THREADS=1',
           '--ulimit','stack=-1:-1','--volume',str(root)+':/work',
           '--workdir','/work',image,'bigdft']
    try:
        run = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        subprocess.run(['docker','rm','-f',name], capture_output=True)
        raise
    (root / 'stdout.txt').write_text(run.stdout)
    (root / 'stderr.txt').write_text(run.stderr)
    log = (root / 'log.yaml').read_text() if (root / 'log.yaml').exists() else ''
    energies = re.findall(r'EKS\s*:\s*([-+0-9.eEdD]+)',log)
    norms = re.findall(r'gnrm\s*:\s*([-+0-9.eEdD]+)', log)
    energy = float(energies[-1].replace('D','E').replace('d','e')) if energies else None
    norm = float(norms[-1].replace('D','E').replace('d','e')) if norms else None
    result = {'image_id':meta['Id'],'repo_digests':meta.get('RepoDigests',[]),
              'library_group':library_group,'returncode':run.returncode,'energy_hartree':energy,'gradient_norm':norm,
              'passed':run.returncode == 0 and energy is not None and math.isfinite(energy)
                       and -2 < energy < -0.5 and norm is not None and norm <= 1.e-4,
              'workdir':str(root)}
    (root / 'result.json').write_text(json.dumps(result, indent=2)+'\n')
    if not result['passed']:
        raise RuntimeError('BigDFT smoke failed; inspect '+str(root / 'result.json'))
    return result

if __name__ == '__main__':
    import argparse
    import json
    parser = argparse.ArgumentParser()
    parser.add_argument('image')
    parser.add_argument('--workdir', default='bigdft-runtime-smoke')
    args = parser.parse_args()
    print(json.dumps(bigdft_runtime_smoke(args.image, args.workdir), indent=2))
