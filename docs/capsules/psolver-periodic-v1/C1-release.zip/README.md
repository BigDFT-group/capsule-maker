# Capsule handover · release format 1

Without Git, run `capsule-maker import-release RELEASE.zip restored`.
Alternatively, extract capsule.zip and use `capsule-maker import`.
Read SUMMARY.md or run `capsule-maker resume restored`.

For history, extract capsule.bundle and clone it offline with Git.
Check out the exact commit in release.json. Review the bundle source before cloning.
Read and verify the snapshot in isolation from .git using Capsule-Maker.
Continue on a new Git branch and review the new capsule before releasing it.

Inspection and import do not execute the scientific procedures.
