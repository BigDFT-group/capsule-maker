# Research Capsule

Continue convergence

Origin: local-file — Deterministic Poisson investigation, session A

## Knowledge

### boundary-decision (decision, verified)

Use zero Dirichlet boundaries and centered finite differences, h=1/n.

Evidence: numerical-evidence
Provenance: session-a
Supersedes: none

### correct-sign (correction, verified)

For -u''=f use (2*u_i-u_(i-1)-u_(i+1))/h^2=f_i with a positive right-hand side.

Evidence: numerical-evidence
Provenance: session-a
Supersedes: wrong-sign

### next-grid (question, unresolved)

Continue at 256 intervals and verify an error ratio close to four.

Evidence: none
Provenance: session-a
Supersedes: none

### numerical-evidence (evidence, verified)

Computed errors at 32,64,128 intervals and rejected-sign error at 32 intervals.

Evidence: none
Provenance: session-a
Supersedes: none

### problem (context, unverified)

Solve -u''=pi^2 sin(pi*x) on [0,1] with u(0)=u(1)=0; exact u=sin(pi*x).

Evidence: none
Provenance: session-a
Supersedes: none

### validated-solver (procedure, verified)

The corrected NumPy tridiagonal solver has second-order maximum-error convergence.

Evidence: numerical-evidence
Provenance: session-a
Supersedes: none

### wrong-sign (failed_attempt, superseded)

Using a negative right-hand side produced a negative solution with max error above 2.

Evidence: numerical-evidence
Provenance: session-a
Supersedes: none

## Source references

- session-a: urn:capsule-maker:poisson:session-a — Reproducible session_a.py calculation and curated research fixture

## Conflicts

None declared or detected.

## Environment

Python >=3.11,<4
- numpy>=1.26,<3

## Receiving instructions

Inspect the manifest, knowledge, evidence, procedures, and tests before approval.
Verify integrity and environment requirements. Import/inspection never run code.
Run tests only after explicit trust using `capsule-maker verify PATH --trust-code`.
Checksums establish integrity, not authorship or scientific validity.
